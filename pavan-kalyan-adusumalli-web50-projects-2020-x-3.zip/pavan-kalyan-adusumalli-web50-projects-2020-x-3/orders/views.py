from django.contrib.auth.models import User
from django.contrib.auth import login, logout, authenticate
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from .models import Customers, Regular, Sicilian , Subs, Pasta, Salads, DinnerPlatters, Toppings
from django.urls import reverse

# Create your views here.
def index(request):
    if(not request.user.is_authenticated):#redirect to login page if user is out of session
        return(render(request, 'orders/login.html'))
    username=request.user.username
    if('admin' in username):
        return(HttpResponseRedirect(reverse('adminorders')))
    return(HttpResponseRedirect(reverse('regular')))

def adminorders(request):
    username=request.user.username
    return(render(request,'orders/adminorders.html',{"username":username}))

def orders(request):
    if(not request.user.is_authenticated):
        return(render(request, 'orders/login.html'))
    username=request.user.username
    return(render(request,'orders/yourorders.html', {'username':username}))

def regular(request):
    regpizzas = Regular.objects.all()
    toppings = Toppings.objects.all()
    counter = [range(1,i.toppings+1) for i in regpizzas]
    username = request.user.username
    #print(regpizzas[1].toppings)
    #counter={0:list(range(regpizzas[0].toppings)), 1:list(range(regpizzas[0].toppings)), 2:list(range(regpizzas[0].toppings))}
    return(render(request, 'orders/regular.html', {'username':username, 'regpizzas': zip(regpizzas,counter), 'toppings':toppings}))#index function initially renders regular pizza html page

def sicilian(request):
    if(not request.user.is_authenticated):
        return(render(request, 'orders/login.html'))
    sicpizzas = Sicilian.objects.all()
    toppings = Toppings.objects.all()
    tpid = ['topping'+str(i.toppings) for i in sicpizzas]
    print(tpid)
    counter = [range(1,i.toppings+1) for i in sicpizzas]
    print(counter)
    return(render(request, 'orders/sicilian.html', {'username':request.user.username ,'sicpizzas':zip(sicpizzas, counter), 'toppings':toppings}))

def subs(request):
    if(not request.user.is_authenticated):
        return(render(request, 'orders/login.html'))
    subs = Subs.objects.all()
    return(render(request, 'orders/subs.html', {'username':request.user.username,'subs': subs}))


def pasta(request):
    pastalist = Pasta.objects.all()
    return(render(request, 'orders/pasta.html', {'username':request.user.username,'pastalist':pastalist}))

def salads(request):
    saladlist = Salads.objects.all()
    return(render(request, 'orders/salads.html', {'username':request.user.username,'salads':saladlist}))

def dplatters(request):
    dplist = DinnerPlatters.objects.all()
    return(render(request, 'orders/dp.html', {'username':request.user.username,'dplist':dplist}))
def signup(request):
    return(render(request, "orders/signup.html"))

def signup_status(request):
    username = request.POST["username"]
    fname = request.POST['firstname']
    lname=request.POST['lastname']
    email = request.POST["email"]
    password1 = request.POST["password"]
    repassword = request.POST["repassword"]
    existed_ones = Customers.objects.all()
    for obj in existed_ones:
        if(username==obj.username):
            return(render(request, "orders/error.html", {'message':'username already exists, Please choose another one'}))
        if(password1==obj.password):
            return(render(request, "orders/error.html", {'message':'Password already exists, Please choose another one'}))
    special_chars = '''!@#$%^&*(){[]}|'"?/<>,.+-=\\'''
    sc=False
    for char in password1:
        if char in special_chars:
            sc=True
            break
    if(sc):
        return(render(request, 'orders/error.html', {'message':'Password should not contain any special characters'}))
    elif(password1 != repassword):
        return(render(request, "orders/error.html", {'message':"Passwords didn't match each other, Tryagain:)"}))
    elif(len(password1)<5):
        return(render(request, "orders/error.html", {"message":'Password should contain atleast 5 characters'}))
    elif(len(username)<5):
        return(render(request, "orders/error.html", {"message":"Username should contain atleast 5 characters"}))
    else:
        user = Customers(username=username, password=password1, mail=email, firstname=fname, lastname=lname)#saved to database
        user.save()
        authaccnt = User.objects.create_user(username, email, password1)#create an account for authentication
        return(HttpResponseRedirect(reverse('login')))


def login_view(request):
    return(render(request, "orders/login.html"))

def loginstatus(request):
    user = request.POST["username"]
    pswd = request.POST["password"]
    existed_ones = Customers.objects.all()
    Userc=None
    for obj in existed_ones:
        #if username and password are correct
        if(user==obj.username and pswd==obj.password):
            #then authenticate user
            print(user)
            Userc = authenticate(request, username=user, password=pswd)
            print(Userc)
    if(Userc is not None):
        login(request, Userc)
        return(HttpResponseRedirect(reverse('index')))
    else:
        return(render(request,"orders/error.html", {'message':'Invalid creditials'}))

def logout_view(request):
    logout(request)
    return(render(request, 'orders/login.html'))

item=dict()
def addtolist(request):
    print(request.POST["item"])