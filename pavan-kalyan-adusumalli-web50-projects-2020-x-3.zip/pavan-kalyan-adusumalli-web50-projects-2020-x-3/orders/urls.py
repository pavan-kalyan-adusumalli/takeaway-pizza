from django.urls import path

from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path("", views.index, name="index"),
    path("login", views.login_view, name="login"),
    path("loginstatus", views.loginstatus, name='loginstatus'),
    path("logout", views.logout_view, name='logout'),
    path("signup", views.signup, name="signup"),
    path("signupstatus", views.signup_status, name="signup_status"),
    path('regular',views.regular,name='regular'),
    path('sicilian', views.sicilian, name='sicilian'),
    path('subs', views.subs, name='subs'),
    path("salads", views.salads, name="salads"),
    path('pasta', views.pasta, name='pasta'),
    path('dinnerplatters', views.dplatters, name='dinnerplatters'),
    path('addtolist', views.addtolist, name='addtolist'),
    path('yourorders', views.orders, name='orders'),
    path('adminorders',views.adminorders, name='adminorders'),
]


urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
