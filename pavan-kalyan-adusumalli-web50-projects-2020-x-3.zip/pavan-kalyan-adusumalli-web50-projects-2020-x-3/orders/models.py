from django.db import models

# Create your models here.
class Customers(models.Model):
    username = models.CharField(max_length=64)
    password = models.CharField(max_length=64)
    mail = models.EmailField(default='some string here')
    firstname = models.CharField(max_length=30, default='some string here')
    lastname = models.CharField(max_length=30, default='some string here')

class Toppings(models.Model):
    topping = models.CharField(max_length=40)

class Regular(models.Model):
    name = models.CharField(max_length=60)
    cost = models.FloatField()
    size = models.CharField(max_length=10)
    toppings = models.IntegerField(default=0)
    pizzaimage = models.ImageField(default='static/pizzalogin5.jpg')
    regularid = models.CharField(max_length=40, default=None)

class Sicilian(models.Model):
    name = models.CharField(max_length=60)
    cost = models.FloatField()
    size = models.CharField(max_length=10)
    toppings = models.IntegerField(default=0)
    pizzaimage = models.ImageField(default='static/pizzalogin5.jpg')
    sicid = models.CharField(max_length=40, default=None)

class Subs(models.Model):
    subname = models.CharField(max_length=60)
    cost = models.FloatField()
    size = models.CharField(max_length=10)
    subimage = models.ImageField(default='static/subs.jpg')
    subid = models.CharField(max_length=40, default=None)

class Pasta(models.Model):
    pastaname = models.CharField(max_length=60)
    cost = models.FloatField()
    pastaimage = models.ImageField(default='static/chickenpasta.jpg')
    pastaid = models.CharField(max_length=40, default=None)

class Salads(models.Model):
    saladname = models.CharField(max_length=60)
    cost = models.FloatField()
    saladimage = models.ImageField(default='static/salad.jpg')
    saladid = models.CharField(max_length=40, default=None)

class DinnerPlatters(models.Model):
    plattername = models.CharField(max_length=60)
    cost = models.FloatField()
    size = models.CharField(max_length=10)
    platterimage = models.ImageField(default='static/dp.jpg')
    dpid = models.CharField(max_length=40, default=None)