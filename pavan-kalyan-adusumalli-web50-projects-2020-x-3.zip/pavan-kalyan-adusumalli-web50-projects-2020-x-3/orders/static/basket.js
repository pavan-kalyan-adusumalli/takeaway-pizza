//var dict = {};


document.addEventListener('DOMContentLoaded', ()=>{
    //when page is loaded
    const template = Handlebars.compile(document.querySelector('#addeditem').innerHTML);//loading template

    //setup local storage for cost if not there
    if(!localStorage.getItem('total')){
        let tot={}
        localStorage.setItem('total',JSON.stringify(tot));
    }

    function loaddict(){
        var dictk = JSON.parse(localStorage.getItem('dict'));
        //alert(dictk);
        for(let item in dictk){
            for(let i in dictk[item]){
        document.querySelector('.addhere').innerHTML += template({'dishname':dictk[item][i][0],'size':dictk[item][i][1], 'cost':dictk[item][i][2]})
        }}
            //alert(item);
            //document.querySelector('.addhere').innerHTML += template({'dishname':dict[item][0],'size':dict[item][1], 'cost':dict[item][2]})
    }
    loaddict();
    
    function buttondisable(){
        var divcount = document.querySelector('#cart div');
        if(divcount)
            document.querySelector('#checkout').disabled=false;
        else
            document.querySelector('#checkout').disabled=true;
    }
    //initially call the buttondisable function to disable button
    buttondisable()

    
    document.addEventListener('click', event=>{
        //identify the target where click happened
        const element = event.target;
        //alert(element.className)
        if(element.className === 'btn btn-success add'){//whenn add is clicked
            
            var x = element.dataset.divid;
            var item = document.querySelector(`#${x} h6`).innerHTML;
            var size = document.querySelector(`#${x} span`).innerHTML 
            var cost = document.querySelector(`#${x} b`).innerHTML; 
            var costflt = Number(cost.slice(1));
            var usname = document.querySelector('#username').innerHTML;
            //add cost to total of local storage on his name
            let total = JSON.parse( localStorage.getItem('total'));
            if(!total[usname]){
                total[usname]=0
                total[usname]+=costflt;
                localStorage.setItem('total',JSON.stringify(total));
            }
            else{
                total[usname]+=costflt;
                localStorage.setItem('total',JSON.stringify(total));
            }
            //total+=costflt;
            alert(document.querySelector(`#${x} h6`).innerHTML);
            alert(document.querySelector(`#${x} span`).innerHTML);
            alert(document.querySelector(`#${x} b`).innerHTML);
            if(document.querySelector(`#${x} select`) && document.querySelector(`#${x} .toppingsid`)){
                var tpgstr=[]
                var tpgno = Number(document.querySelector(`#${x} #tpgno`).innerHTML);
                alert(tpgno)
                for(let i=0; i< tpgno; i++)
                    tpgstr.push(toppingsArr[i])
                alert(`Selected toppings : ${tpgstr}`);

                if(!localStorage.getItem('dict')){
                    let initdict = {};
                    localStorage.setItem('dict',JSON.stringify(initdict))
                    let dict1 = JSON.parse(localStorage.getItem('dict'));
                    if(!dict1[item])
                        dict1[item]=[]//if empty list of item not found create one
                    dict1[item].push([item,size,cost,tpgstr])
                    localStorage.setItem('dict',JSON.stringify(dict1));
                }
                else{
                    let dict2 = JSON.parse(localStorage.getItem('dict'));
                    if(!dict2[item])//if no empty list of item create one
                        dict2[item]=[]
                    dict2[item].push([item,size,cost,tpgstr])
                    localStorage.setItem('dict',JSON.stringify(dict2));
                }
                let dict3 = JSON.parse(localStorage.getItem('dict'));
                //alert(`${localStorage.getItem('dict')} ls`);
                //remove existing items and add other
                document.querySelectorAll('.addhere div').forEach(div=>{
                    div.remove()
                })
                for(let item in dict3){
                    for(let i in dict3[item]){
                document.querySelector('.addhere').innerHTML += template({'dishname':dict3[item][i][0],'size':dict3[item][i][1], 'cost':dict3[item][i][2]})
                }}//var tpgstr is there
            }

            //if no toppings
            else{

                if(!localStorage.getItem('dict')){
                    let initdict2 = {}
                    localStorage.setItem('dict',JSON.stringify(initdict2));
                    let dic = JSON.parse(localStorage.getItem('dict'));
                    if(!dic[item])
                        dic[item]=[]
                    dic[item].push([item,size,cost]);
                    localStorage.setItem('dict',JSON.stringify(dic));
                }
                else{
                    let dic2 = JSON.parse(localStorage.getItem('dict'));
                    if(!dic2[item])
                        dic2[item]=[]
                    dic2[item].push([item,size,cost]);
                    localStorage.setItem('dict',JSON.stringify(dic2));
                }
                let dic3 = JSON.parse(localStorage.getItem('dict'));
                //alert(`${localStorage.getItem('dict')} `);
                //remove existing items and add other
                document.querySelectorAll('.addhere div').forEach(div=>{
                    div.remove()
                })
                for(let item in dic3){
                    for(let i in dic3[item]){
                document.querySelector('.addhere').innerHTML += template({'dishname':dic3[item][i][0],'size':dic3[item][i][1], 'cost':dic3[item][i][2]})
                    }}
            }

            //alert(element.parentNode);
            //alert(element.parentNode.innerHtml);
        }
    });

        var toppingsArr = ['Pepporoni','Sausage','Mushrooms'];
        document.querySelectorAll('.toppingsid').forEach(topping =>{
            topping.onchange = ()=>{
                //document.querySelector("#toppings").onchange = function(){
                    var addedtopping=topping.value;
                    //var addedtopping = tpg.value;
                    toppingsArr.unshift(addedtopping);
                    //alert(toppingsArr.toString());
            }
        });

        document.addEventListener('click', event=>{
            //identify the target where click happened
            const element = event.target;
            if(element.className === 'border border-light remove'){
                    element.parentElement.remove();
                    var d = JSON.parse(localStorage.getItem('dict'));
                    localStorage.setItem('dict',d);
                }
            buttondisable();
        });

        document.addEventListener('click', event=>{
            //identify the target where click happened
            const element = event.target;
            if(element.className === 'clearcart'){
                element.parentElement.querySelectorAll('div').forEach(div=>{
                    div.remove()
                    document.querySelector('#checkout').disabled=true;
                });
                localStorage.clear();
            }
        });

        document.addEventListener('click', event=>{
            //when checkout happened
            const element = event.target;
            if(element.className === 'btn btn-warning'){
                var username = document.querySelector('#username').innerHTML;
                var orders = JSON.parse(localStorage.getItem('dict'));
                let total=JSON.parse(localStorage.getItem('total'));
                if(!localStorage.getItem('orders')){
                    let ordersstr=''
                    for(let key in orders)
                        ordersstr += JSON.stringify(orders[key]);
                    let ordersdict = {};
                    ordersdict[username]=[[ordersstr,'pending',total[username]]]
                    localStorage.setItem('orders',JSON.stringify(ordersdict));

                    //now get the dict
                }
                else{
                    let ordersstr=''
                    for(let key in orders)
                        ordersstr += JSON.stringify(orders[key]);
                    let ordersdict = JSON.parse(localStorage.getItem('orders'));
                    
                    if(!ordersdict[username])
                        ordersdict[username]=[]//make an empty list if username do not found
                    ordersdict[username].push([ordersstr,'pending',total[username]])
                    localStorage.setItem('orders',JSON.stringify(ordersdict));

                }
                //alert(localStorage.getItem('orders'));
                alert(`Total cost $${total[username]} click ok to confirm`);
                //total=0;//make total 0 once order is placed
                total[username]=0
                localStorage.setItem('total',JSON.stringify(total))
                localStorage.removeItem('dict');
                //buttondisable();
                element.parentElement.querySelectorAll('div').forEach(div=>{
                    div.remove()
                    document.querySelector('#checkout').disabled=true;
                });

            }
        });
    
})