from django.contrib import admin
from .models import Customers, Regular, Sicilian, Toppings, Subs, Salads, Pasta, DinnerPlatters
# Register your models here.

admin.site.register(Customers)
admin.site.register(Regular)
admin.site.register(Sicilian)
admin.site.register(Toppings)
admin.site.register(Subs)
admin.site.register(Pasta)
admin.site.register(Salads)
admin.site.register(DinnerPlatters)