# Project 3

Web Programming with Python and JavaScript

Restaurant owner's account info to confirm customer orders => "on point 8"
(for owner account to operate order status : If you want a new owner account, it can be created using admin iterface with 'admin'(word) in username)

1. about Login page: This page contains a form where user can loginto website using their username and password. If they do not have those they can create an account by clicking      on signup button. Their info will be remembered once they logged in.

2. about signup page(Registration): To create an account one should give their first name, lastname, mail-id, username, password(to be created).

3. about home page: Initially when the user logged into site they will be redirected to regular pizzas menu page. where they can select their pizzas, add to cart, and finally        place order.

4. about menu: Each type of dishes based on their categories(i.e. regular pizzas, sicilian pizzas, subs, pasta, salads, dinner platters) in Pinocchios menu card are displayed on      seperate pages. User can access them by clicking on corresponding buttons.

5. Adding Items: Using Django Admin, site administrators (restaurant owners) can be able to add, update, and remove items on the menu.

6. Adding items to cart: User can add an item to cart by clicking the "add" button placed on every item. by doing so they can add their items to cart. They can also choose            toppings using dropdowns in case of pizzas.

7. Order items: To place the order the users has to click checkout button and confirm the price. They can place order only when there is atleast one item in their cart.

8. viewing orders: Uers => once order is placed they can see their orders by clicking on Your orders link. They can also see the status of their orders placed(completed/pending).
   Owners => Site administrators have access to a page where they can view any orders that have already been placed.

9. additional feature:The restaurant owners has seperate account(username: "adminofsite", password: adminpassword), by using this account they can confirm the orders. 
   Whenever they confirm the orders customers of site can see the status of order.

10. Users/siteadmins can logout as when whenever they want.
